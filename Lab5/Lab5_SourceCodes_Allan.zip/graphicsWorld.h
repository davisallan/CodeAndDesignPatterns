/*
* File Name: graphicsWorld.h
* Lab # and Assignment #: Lab 5 Exercise A
* Lab section: B01
* Completed by: Davis Allan, 10016543
* Submission Date: Oct 22 2020
*/

#ifndef GRAPHICS_WORLD_H
#define GRAPHICS_WORLD_H

class GraphicsWorld {
    public:
        void run();
};

#endif