/*
 * File Name: Item.java
 * Lab # and Assignment #: Lab 6 Exercise C and D
 * Lab section: B01
 * Completed by: Davis Allan, 10016543
 * Submission Date: Oct 30 2020
 */
class Item {
	private Double item;
	public Item(Double value) {
		item = value;
	}
	
	public void setItem(Double value){
		item = value;
	}
	
	public Double getItem(){
		return item;
	}
}
