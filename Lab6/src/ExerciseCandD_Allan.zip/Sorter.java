 /*
  * File Name: Sorter.java
  * Lab # and Assignment #: Lab 6 Exercise C and D
  * Lab section: B01
  * Completed by: Davis Allan, 10016543
  * Submission Date: Oct 30 2020
  */

import java.util.ArrayList;

public interface Sorter {
    void sort(ArrayList<Item> arr);
}
