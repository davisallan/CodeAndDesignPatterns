/*
* File Name: curveCut.cpp
* Lab # and Assignment #: Lab 5 Exercise B
* Lab section: B01
* Completed by: Davis Allan, 10016543
* Submission Date: Oct 22 2020
*/

#include "square.h"
#include "circle.h"
#include "curveCut.h"
#include <math.h>
#include <iostream>
#include <algorithm>

using namespace std;

CurveCut::CurveCut(double x, double y, double length, double width, double radius, const char *name)
        : Shape(x, y, name), Square(x, y, length, name), Circle(x, y, radius, name), width(width) {
    if (radius > min(width,length)){
        cerr << "Error, radius is larger than min(width, length), exiting..." << endl;
        exit(1);
    }
}

double CurveCut::area() const{
    return (getSideA() * getWidth()) - (Circle::area() / 4);
}

double CurveCut::perimeter() const {
    double widthPerim = getWidth() + (getWidth() - getRadius());
    double lengthPerim = getSideA() + (getSideA() - getRadius());
    double circlePerim = Circle::perimeter() / 4;
    return widthPerim + lengthPerim + circlePerim;
}

void CurveCut::display() const{
    cout << "CurveCut name: " << getName() << endl;
    getOrigin().display();
    cout << "Width: " << getWidth() << endl;
    cout << "Length: " << getSideA() << endl;
    cout << "Radius of the cut: " << getRadius() << endl;
}
