/*
 * File Name: User.hpp
 * Lab # and Assignment #: Lab 7 Exercise D
 * Lab section: B01
 * Completed by: Davis Allan, 10016543
 * Submission Date: Nov 6 2020
 */
#include <string>
using namespace std;

#ifndef USER_H
#define USER_H

struct User {
    string username;
    string password;
};

#endif